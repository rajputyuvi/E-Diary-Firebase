package com.example.ediary;

import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;

public class Dashboard extends AppCompatActivity {
    CardView i1, i2, i3, i4; // transport = i4

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_dashboard);

        i1 = findViewById(R.id.student);
        i2 = findViewById(R.id.teacher);
        i3 = findViewById(R.id.admin);
        i4 = findViewById(R.id.transport); // fixed

        i1.setOnClickListener(v -> startActivity(new Intent(Dashboard.this, StudentLogin.class)));
        i2.setOnClickListener(v -> startActivity(new Intent(Dashboard.this, TeacherLogin.class)));
        i3.setOnClickListener(v -> startActivity(new Intent(Dashboard.this, AdminLogin.class)));
        i4.setOnClickListener(v -> startActivity(new Intent(Dashboard.this, TransportActivity.class))); // adjust activity name
    }
}
