package com.example.ediary;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;

//import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

public class FetchAssignMent extends AppCompatActivity {

    List<MetaStudentAssignMent> productList;

    //the recyclerview
    RecyclerView recyclerView;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
       // EdgeToEdge.enable(this);
        setContentView(R.layout.activity_fetchassignment);


        recyclerView = findViewById(R.id.recylcerView);
        recyclerView.setHasFixedSize(true);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        productList = new ArrayList<>();

        //this method will fetch and parse json
        //to display it in recyclerview
        loadProducts();
    }
    private void loadProducts()
    {
        Intent in = getIntent();
        String s1= in.getStringExtra("subject");
        String s2=in.getStringExtra("topic");
        String s3=in.getStringExtra("description");
        String s4= in.getStringExtra("uploadedby");

        String s5=in.getStringExtra("date");
        String phn=in.getStringExtra("name");


        String cleanDescription = s3 != null ? s3.replaceAll("\\s+", " ").trim() : "";


        //String description=in.getStringExtra("weight");
        //Toast.makeText(getApplicationContext(),nn,Toast.LENGTH_LONG).show();

        /*
         * Creating a String Request
         * The request type is GET defined by first parameter
         * The URL is defined in the second parameter
         * Then we have a Response Listener and a Error Listener
         * In response listener we will get the JSON response as a String
         * */
        //  Intent in= getIntent();
        // String testt= ((Intent) in).getStringExtra("name");
        String ss="jaineetkour796@gmail.com";

        final String URL_PRODUCTS = "https://letuslearnenglish.in/jaineet/mydoctor.php?test=" + s1 + "&ht=" + s2 + "&wt=" + s3 + "&tt=" + s4 + "&qt=" + phn;
        StringRequest stringRequest = new StringRequest(Request.Method.GET, URL_PRODUCTS,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        try {
                            //converting the string to json array object
                            JSONArray array = new JSONArray(response);

                            //traversing through all the object
                            for (int i = 0; i < array.length(); i++) {

                                //getting product object from json array
                                JSONObject product = array.getJSONObject(i);

                                //adding the product to product list
                                productList.add(new MetaStudentAssignMent(
                                        product.getString("f1"),
                                        product.getString("f2"),
                                        product.getString("f3"),
                                        product.getString("f4"),
                                        product.getString("f5"),
                                        product.getString("spec")

                                ));
                            }

                            //creating adapter object and setting it to recyclerview
                            com.example.ediary.StudentAssigmentAdapter adapter = new com.example.ediary.StudentAssigmentAdapter(FetchAssignMent.this,productList);

                            recyclerView.setAdapter(adapter);
                        } catch (JSONException e) {
                            e.printStackTrace();
                        }
                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        Toast.makeText(getApplicationContext(),"not working",Toast.LENGTH_LONG).show();
                    }

                });

        //adding our stringrequest to queue
        Volley.newRequestQueue(this).add(stringRequest);
    }

}