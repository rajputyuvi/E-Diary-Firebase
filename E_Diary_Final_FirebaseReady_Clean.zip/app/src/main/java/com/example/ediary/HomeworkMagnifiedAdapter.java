package com.example.ediary;
import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

public class HomeworkMagnifiedAdapter extends RecyclerView.Adapter< HomeworkMagnifiedAdapter .ProductViewHolder> {
    Button b;
    private Context mCtx;
    private List<MetaStudentAssignMent> productList;

    public HomeworkMagnifiedAdapter(Context mCtx, List<MetaStudentAssignMent> productList) {
        this.mCtx = mCtx;
        this.productList = productList;
    }


    public HomeworkMagnifiedAdapter.ProductViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        LayoutInflater inflater = LayoutInflater.from(mCtx);
        View view = inflater.inflate(R.layout.mydairy,null);
        return new com.example.ediary.HomeworkMagnifiedAdapter.ProductViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull com.example.ediary.HomeworkMagnifiedAdapter.ProductViewHolder holder, int position) {
        MetaStudentAssignMent product = productList.get(position);

        //loading the image
        //  Glide.with(mCtx)
        //    .load(product.getImage())
        //  .into(holder.imageView);

        holder.textViewId.setText(product.getB_area());
        holder.textViewArea.setText(product.getB_email());
        holder.textViewWardno.setText(product.getB_work());
        holder.textViewLocality.setText(product. getB_wardno());
        holder.textViewCity.setText(product.getB_ward());
        String id=product.getB_spec();
        // holder.textViewLocality.setText(String.valueOf(product.getB_wardno()));


    }

    @Override
    public int getItemCount() {
        return productList.size();
    }

    class ProductViewHolder extends RecyclerView.ViewHolder {

        TextView textViewId,textViewArea, textViewWardno, textViewLocality, textViewCity, textViewEmail,textViewRoute;

        ImageView imageView;
        Button updateMap,updateBin;

        public ProductViewHolder(View itemView) {
            super(itemView);
            //imageView=itemView.findViewById(R.id.ing);
            textViewId=itemView.findViewById(R.id.c1);
            textViewArea = itemView.findViewById(R.id.c2);
            textViewWardno=itemView.findViewById(R.id.c3);
            textViewLocality=itemView.findViewById(R.id.c4);
            textViewCity=itemView.findViewById(R.id.c5);



            /* textViewCity.setEnabled(false);
             textViewArea.setEnabled(false);
             textViewWardno.setEnabled(false);
             textViewLocality.setEnabled(false);
             textViewId.setEnabled(false);*/


            // imageView = itemView.findViewById(R.id.imageView);
        }
    }

}
