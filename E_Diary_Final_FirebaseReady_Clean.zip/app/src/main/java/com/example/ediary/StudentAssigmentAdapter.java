package com.example.ediary;
import android.content.Context;
import android.content.Intent;
import android.speech.tts.TextToSpeech;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.PopupMenu;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.cardview.widget.CardView;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;
import java.util.Locale;

public class StudentAssigmentAdapter extends RecyclerView.Adapter<StudentAssigmentAdapter.ProductViewHolder> {

    private Context mCtx;
    private List<MetaStudentAssignMent> productList;
    private TextToSpeech textToSpeech;

    public StudentAssigmentAdapter(Context mCtx, List<MetaStudentAssignMent> productList) {
        this.mCtx = mCtx;
        this.productList = productList;

        // Initialize TTS
        textToSpeech = new TextToSpeech(mCtx.getApplicationContext(), status -> {
            if (status == TextToSpeech.SUCCESS) {
                textToSpeech.setLanguage(Locale.US); // Default to English
            }
        });
    }

    @NonNull
    @Override
    public ProductViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        LayoutInflater inflater = LayoutInflater.from(mCtx);
        View view = inflater.inflate(R.layout.mydairy, null);
        return new ProductViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ProductViewHolder holder, int position) {
        MetaStudentAssignMent product = productList.get(position);

        holder.textViewId.setText(product.getB_area());
        holder.textViewArea.setText(product.getB_email());
        String cleanedText = product.getB_work().replaceAll("\\s+", " ").trim();
        holder.textViewWardno.setText(cleanedText);
        holder.textViewLocality.setText(product.getB_wardno());
        holder.textViewCity.setText(product.getB_ward());

        String fullText = product.getB_email() + " " + product.getB_work();
        String id = product.getB_spec();

        holder.textViewEmail.setOnClickListener(view -> {
            Intent pop = new Intent(mCtx.getApplicationContext(), HomeworkMagnified.class);
            pop.putExtra("id", id);
            mCtx.startActivity(pop);
        });

        holder.imageView.setOnClickListener(v -> {
            PopupMenu popupMenu = new PopupMenu(mCtx, holder.imageView);
            popupMenu.getMenuInflater().inflate(R.menu.language, popupMenu.getMenu());

            popupMenu.setOnMenuItemClickListener(item -> {
                int itemId = item.getItemId();

                if (itemId == R.id.english) {
                    textToSpeech.setLanguage(Locale.US);
                    textToSpeech.speak(fullText, TextToSpeech.QUEUE_FLUSH, null, null);
                    return true;

                } else if (itemId == R.id.hindi) {
                    int langResult = textToSpeech.setLanguage(new Locale("hi", "IN"));
                    if (langResult == TextToSpeech.LANG_MISSING_DATA || langResult == TextToSpeech.LANG_NOT_SUPPORTED) {
                        Toast.makeText(mCtx, "Hindi not supported", Toast.LENGTH_SHORT).show();
                    } else {
                        textToSpeech.speak(fullText, TextToSpeech.QUEUE_FLUSH, null, null);
                    }
                    return true;
                }

                return false;
            });

            popupMenu.show();
        });
    }

    @Override
    public int getItemCount() {
        return productList.size();
    }

    class ProductViewHolder extends RecyclerView.ViewHolder {

        TextView textViewId, textViewArea, textViewWardno, textViewLocality, textViewCity;
        ImageView imageView;
        CardView textViewEmail;

        public ProductViewHolder(View itemView) {
            super(itemView);
            textViewId = itemView.findViewById(R.id.c1);
            textViewArea = itemView.findViewById(R.id.c2);
            textViewWardno = itemView.findViewById(R.id.c3);
            textViewLocality = itemView.findViewById(R.id.c4);
            textViewCity = itemView.findViewById(R.id.c5);
            textViewEmail = itemView.findViewById(R.id.cardd);
            imageView = itemView.findViewById(R.id.sound);
        }
    }
}
