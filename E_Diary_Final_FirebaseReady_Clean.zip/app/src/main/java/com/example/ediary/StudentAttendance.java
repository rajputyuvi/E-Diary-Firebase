package com.example.ediary;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import com.github.mikephil.charting.charts.PieChart;
import android.graphics.Color;
import android.os.Handler;
import android.os.Looper;
import android.widget.TextView;
import android.widget.Toast;

import com.github.mikephil.charting.charts.PieChart;
import com.github.mikephil.charting.components.Description;
import com.github.mikephil.charting.data.PieData;
import com.github.mikephil.charting.data.PieDataSet;
import com.github.mikephil.charting.data.PieEntry;
import com.prolificinteractive.materialcalendarview.CalendarDay;
import com.prolificinteractive.materialcalendarview.MaterialCalendarView;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.Locale;

public class StudentAttendance extends AppCompatActivity {
    PieChart pieChart;
    String s1;
    TextView tv,tvv;
    MaterialCalendarView calendarView;
    ArrayList<CalendarDay> presentDates = new ArrayList<>();


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_studentattendance);
        pieChart = findViewById(R.id.pieChart);
        tv = findViewById(R.id.ll);
        tvv = findViewById(R.id.absent);
        calendarView = findViewById(R.id.calendarView);
        MaterialCalendarView calendarView = findViewById(R.id.calendarView);

// Example: List of present dates
        ArrayList<CalendarDay> presentDates = new ArrayList<>();
        presentDates.add(CalendarDay.from(2025, 4, 8)); // May 8, 2025

        calendarView.addDecorator(new Presentdaydecorator(this, presentDates));

        Intent in = getIntent();
        s1 = in.getStringExtra("name");

        fetchAttendanceData();
    }

    private void fetchAttendanceData() {
        new Thread(() -> {
            try {
                String URL_GET = "https://letuslearnenglish.in/jaineet/attendance_fetch.php?text=" + s1;
                URL url = new URL(URL_GET);
                HttpURLConnection conn = (HttpURLConnection) url.openConnection();
                conn.setRequestMethod("GET");

                BufferedReader in = new BufferedReader(new InputStreamReader(conn.getInputStream()));
                StringBuilder response = new StringBuilder();
                String inputLine;

                while ((inputLine = in.readLine()) != null) {
                    response.append(inputLine);
                }
                in.close();

                JSONArray jsonArray = new JSONArray(response.toString());

                int present = 0, absent = 0, leave = 0, halfday = 0, holiday = 0;

                for (int i = 0; i < jsonArray.length(); i++) {
                    JSONObject obj = jsonArray.getJSONObject(i);
                    String status = obj.getString("status");
                    String dateStr = obj.getString("date");  // expected format: "yyyy-MM-dd"

                    // Count Attendance statuses
                    switch (status.toLowerCase()) {
                        case "present":
                            present++;
                            // Mark the present dates in calendar
                            SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd", Locale.getDefault());
                            Date date = sdf.parse(dateStr);
                            Calendar cal = Calendar.getInstance();
                            cal.setTime(date);
                            presentDates.add(CalendarDay.from(cal));
                            break;
                        case "absent":
                            absent++;
                            //tv.setText(absent);
                            break;
                        case "leave":
                            leave++;
                            break;
                        case "half day":
                            halfday++;
                            break;
                        case "holiday":
                            holiday++;
                            break;
                    }
                }

                // Create the pie chart entries
                ArrayList<PieEntry> entries = new ArrayList<>();
                if (present > 0) entries.add(new PieEntry(present, "Present"));
                if (absent > 0) entries.add(new PieEntry(absent, "Absent"));
                if (leave > 0) entries.add(new PieEntry(leave, "Leave"));
                if (halfday > 0) entries.add(new PieEntry(halfday, "Half Day"));
                if (holiday > 0) entries.add(new PieEntry(holiday, "Holiday"));
String abs=Integer.toString(present);
                tv.setText(String.format("Present:\n %d", present));

                String ssd=Integer.toString(absent);
                tvv.setText(String.format("Absent:\n %d", absent));
               // tvv.setText(ssd);



                // Update UI on the main thread
                new Handler(Looper.getMainLooper()).post(() -> {
                    showChart(entries);
                    calendarView.addDecorator(new Presentdaydecorator(this,presentDates)); // Highlight present dates
                });

            } catch (Exception e) {
                e.printStackTrace();
            }
        }).start();
    }

    private void showChart(ArrayList<PieEntry> entries) {
        if (entries == null || entries.size() == 0) {
            Toast.makeText(this, "No Attendance data found", Toast.LENGTH_LONG).show();
            return;
        }

        PieDataSet dataSet = new PieDataSet(entries, "Attendance Summary");
        dataSet.setColors(
                getResources().getColor(android.R.color.holo_green_dark),   // Present
                getResources().getColor(android.R.color.holo_red_dark),     // Absent
                getResources().getColor(android.R.color.holo_orange_dark),  // Leave
                getResources().getColor(android.R.color.holo_blue_dark),    // Half Day
                getResources().getColor(android.R.color.darker_gray)        // Holiday
        );

        dataSet.setValueTextColor(Color.WHITE);
        dataSet.setValueTextSize(14f);

        PieData data = new PieData(dataSet);
        pieChart.setData(data);
        pieChart.setDrawHoleEnabled(false);

        Description description = new Description();
        description.setText("");
        pieChart.setDescription(description);
        pieChart.invalidate(); // Refresh chart
        //tv.setText(absent);
    }
}