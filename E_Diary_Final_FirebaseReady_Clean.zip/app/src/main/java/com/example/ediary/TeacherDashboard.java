package com.example.ediary;
import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

public class TeacherDashboard extends AppCompatActivity {
    CardView c1,c2,c3;
    Button ll,B2;
    TextView pop;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_teacherdashboard);
        c1= (CardView) findViewById(R.id.mycard);
        c2= (CardView) findViewById(R.id.uploadcircular);
        B2= (Button) findViewById(R.id.addstudenttt);
pop=(TextView)findViewById(R.id.kk);
pop.setOnClickListener(new View.OnClickListener() {
    @Override
    public void onClick(View view) {
        Intent pop = new Intent(getApplicationContext(),AssignBus.class);
        startActivity(pop);
    }
});
        ll=(Button) findViewById(R.id.Attendance);
        ll.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent pp= new Intent(getApplicationContext(), Attendance.class);
                startActivity(pp);
            }
        });

        c1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent pp = new Intent(TeacherDashboard.this, TeacherHomeworkAssign.class);
                startActivity(pp);


            }
        });
        c2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
            Intent pp = new Intent(TeacherDashboard.this, TeacherCircular.class);
            startActivity(pp);
            }
        });
        B2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent pp = new Intent(TeacherDashboard.this, AddStudentDetails.class);
                startActivity(pp);
            }
        });




    }
}