package com.example.ediary;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;

import androidx.appcompat.app.AppCompatActivity;

public class StudentLogin extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_student_login);

        Button btnLogin = findViewById(R.id.btnStudentLogin);

        btnLogin.setOnClickListener(v -> {
            // After login go to Student Attendance page
            Intent intent = new Intent(StudentLogin.this, StudentAttendance.class);
            startActivity(intent);
            finish();
        });
    }
}
