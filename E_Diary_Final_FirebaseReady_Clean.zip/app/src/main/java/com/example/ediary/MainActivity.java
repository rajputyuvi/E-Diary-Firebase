package com.example.ediary;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.widget.Toolbar;

import androidx.appcompat.app.AppCompatActivity;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import java.util.HashMap;
import java.util.Map;

public class MainActivity extends AppCompatActivity {
    Button b1,b2;
    EditText e1 ,e2;
    TextView t1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        b1= (Button) findViewById(R.id.loginbutton);

        e1=(EditText) findViewById(R.id.username);
        e2=(EditText) findViewById(R.id.password);
        t1=(TextView) findViewById(R.id.forgotpassword);


       // t1.setOnClickListener(new View.OnClickListener() {
         //   @Override
           // public void onClick(View view) {
                //Intent pp = new Intent(MainActivity.this, forgotpassword.class);
                //startActivity(pp);


          //  }
       // });
       // b2.setOnClickListener(new View.OnClickListener() {
          //  @Override
          //  public void onClick(View view) {
            //    Intent pp = new Intent(MainActivity.this,Signup.class);
              //  startActivity(pp);


           // }
       // });
        b1.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View view) {
                String s1, s2;
                s1 = e1.getText().toString();
                s2 = e2.getText().toString();

                final String HI  ="https://letuslearnenglish.in/jaineet/login.php";

                StringRequest stringRequest = new StringRequest(Request.Method.POST,HI, new Response.Listener<String>() {
                    @Override

                    public void onResponse(String response) {
                        String ss=response.toString();
                        Toast.makeText(MainActivity.this, ss, Toast.LENGTH_LONG).show();


                         Intent intent = new Intent(MainActivity.this, Dashboard.class);
                         intent.putExtra("name",s1);
                         startActivity(intent);
                    }




                }, new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        Toast.makeText(MainActivity.this, "data not saved", Toast.LENGTH_LONG).show();
                    }

                }) {
                    @Override
                    protected Map<String, String> getParams() throws AuthFailureError {
                        Map<String, String> parms = new HashMap<String, String>();

                        parms.put("s1", s1);
                        parms.put("s2", s2);

                        return parms;
                    }
                };
                RequestQueue requestQueue = Volley.newRequestQueue(getApplicationContext());
                requestQueue.add(stringRequest);
            }
        });



    }
}





