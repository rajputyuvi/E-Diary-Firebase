package com.example.ediary;
import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

public class BusAdapter extends RecyclerView.Adapter< BusAdapter .ProductViewHolder> {
    Button b;
    private Context mCtx;
    private List<MetaBus> productList;

    public BusAdapter(Context mCtx, List<MetaBus> productList) {
        this.mCtx = mCtx;
        this.productList = productList;
    }


    public BusAdapter.ProductViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        LayoutInflater inflater = LayoutInflater.from(mCtx);
        View view = inflater.inflate(R.layout.mybus,null);
        return new com.example.ediary.BusAdapter.ProductViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull com.example.ediary.BusAdapter.ProductViewHolder holder, int position) {
        MetaBus product = productList.get(position);

        //loading the image
        //  Glide.with(mCtx)
        //    .load(product.getImage())
        //  .into(holder.imageView);

        holder.textViewId.setText(product.getB_area());

        holder.textViewArea.setText(String.valueOf(product.getB_email()));
        holder.textViewCity.setText(String.valueOf(product.getB_work()));

        holder.textViewLocality.setText(String.valueOf(product.getB_ward()));

        holder.textViewEmail.setText(String.valueOf(product.getB_driver()));
        holder.textViewRoute.setText(String.valueOf(product.getB_incharge()));
        String ss=product.getB_wardno();



    }

    @Override
    public int getItemCount() {
        return productList.size();
    }

    class ProductViewHolder extends RecyclerView.ViewHolder {

        TextView textViewId,textViewArea, textViewWardno, textViewLocality, textViewCity, textViewEmail,textViewRoute;

        ImageView imageView;
        Button updateMap,updateBin;

        public ProductViewHolder(View itemView) {
            super(itemView);
            //imageView=itemView.findViewById(R.id.ing);
            textViewId=itemView.findViewById(R.id.a);
            textViewArea=itemView.findViewById(R.id.b);
            textViewCity=itemView.findViewById(R.id.c);
            textViewLocality=itemView.findViewById(R.id.d);
            textViewEmail=itemView.findViewById(R.id.e);
            textViewRoute=itemView.findViewById(R.id.f);




            /* textViewCity.setEnabled(false);
             textViewArea.setEnabled(false);
             textViewWardno.setEnabled(false);
             textViewLocality.setEnabled(false);
             textViewId.setEnabled(false);*/


            // imageView = itemView.findViewById(R.id.imageView);
        }
    }

}
