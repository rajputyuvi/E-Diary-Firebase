package com.example.ediary;
import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.util.SparseBooleanArray;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.toolbox.JsonArrayRequest;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;

public class Attendance extends AppCompatActivity {
    ListView studentListView;
    Button submitButton;
    ArrayList<Student> studentList = new ArrayList<>();
    ArrayAdapter<String> adapter;
    boolean[] checkedItems;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_attendance);
        studentListView = findViewById(R.id.studentListView);
        submitButton = findViewById(R.id.submitButton);

        fetchStudents();

        submitButton.setOnClickListener(v -> submitAttendance());
    }

    private void fetchStudents() {
        String url = "https://letuslearnenglish.in/jaineet/get_students.php";

        StringRequest request = new StringRequest(Request.Method.GET, url,
                response -> {
                    try {
                        JSONArray array = new JSONArray(response);
                        String[] names = new String[array.length()];
                        checkedItems = new boolean[array.length()];

                        for (int i = 0; i < array.length(); i++) {
                            JSONObject obj = array.getJSONObject(i);
                            studentList.add(new Student(obj.getInt("id"), obj.getString("stuname")));
                            names[i] = obj.getString("stuname");
                        }

                        adapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_multiple_choice, names);
                        studentListView.setAdapter(adapter);
                        studentListView.setChoiceMode(ListView.CHOICE_MODE_MULTIPLE);

                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                },
                error -> Toast.makeText(this, "Failed to load", Toast.LENGTH_SHORT).show());

        Volley.newRequestQueue(this).add(request);
    }

    private void submitAttendance() {
        SparseBooleanArray checked = studentListView.getCheckedItemPositions();
        JSONArray data = new JSONArray();

        for (int i = 0; i < studentList.size(); i++) {
            boolean isChecked = checked.get(i);
            JSONObject record = new JSONObject();
            try {
                record.put("id", studentList.get(i).getId());
                record.put("status", isChecked ? "Present" : "Absent");
                data.put(record);
            } catch (JSONException e) {
                e.printStackTrace();
            }
        }

        String url = "https://letuslearnenglish.in/jaineet/submit_attendance.php";
        JsonArrayRequest request = new JsonArrayRequest(Request.Method.POST, url, data,
                response -> Toast.makeText(this, "Attendance Saved", Toast.LENGTH_SHORT).show(),
                error -> Toast.makeText(this, "Error submitting", Toast.LENGTH_SHORT).show());

        Volley.newRequestQueue(this).add(request);
    }
}
