package com.example.ediary;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

public class CircularNews extends AppCompatActivity {
    List<MetaCircular> productList;
    RecyclerView recyclerView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_circularnews);
        recyclerView = findViewById(R.id.recylcerView);
        recyclerView.setHasFixedSize(true);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        productList = new ArrayList<>();
        loadProducts();
    }
    private void loadProducts()
    {
        Intent in = getIntent();
        String s1= in.getStringExtra("notice");
        String s2=in.getStringExtra("uploadedby");
        //String s3=in.getStringExtra("description");
      //  String s4= in.getStringExtra("uploadedby");
      //  String s5=in.getStringExtra("date");
     //   String phn=in.getStringExtra("name");
        //String description=in.getStringExtra("weight");
        //Toast.makeText(getApplicationContext(),nn,Toast.LENGTH_LONG).show();
        String ss="jaineetkour796@gmail.com";

        final String URL_PRODUCTS = "https://letuslearnenglish.in/jaineet/jaimycircularr.php? test=" + s1 + "&ht=" + s2 ;
        StringRequest stringRequest = new StringRequest(Request.Method.GET, URL_PRODUCTS,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        try {
                            //converting the string to json array object
                            JSONArray array = new JSONArray(response);

                            //traversing through all the object
                            for (int i = 0; i < array.length(); i++) {

                                //getting product object from json array
                                JSONObject product = array.getJSONObject(i);

                                //adding the product to product list
                                productList.add(new MetaCircular(
                                        product.getString("f1"),
                                        product.getString("f2")
                                        //product.getString("f3"),
                                      //  product.getString("f4"),
                                      //  product.getString("f5")
                                ));
                            }

                            //creating adapter object and setting it to recyclerview
                            com.example.ediary.CircularAdapter adapter = new com.example.ediary.CircularAdapter(CircularNews.this,productList);

                            recyclerView.setAdapter(adapter);
                        } catch (JSONException e) {
                            e.printStackTrace();
                        }
                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        Toast.makeText(getApplicationContext(),"not working",Toast.LENGTH_LONG).show();
                    }
                });

        //adding our stringrequest to queue
        Volley.newRequestQueue(this).add(stringRequest);
    }

}
