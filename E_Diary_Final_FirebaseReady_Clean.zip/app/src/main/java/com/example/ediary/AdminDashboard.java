package com.example.ediary;
import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class AdminDashboard extends AppCompatActivity {
    CardView c1,c2,c3;
    Button ll;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_admindashboard);
        c1= (CardView) findViewById(R.id.mycard);
        c2= (CardView) findViewById(R.id.uploadcircular);



        ll=(Button) findViewById(R.id.Attendance);
        ll.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
              //  Intent pp= new Intent(getApplicationContext(), TeacherList.class);
               // startActivity(pp);
            }
        });

        c1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent pp = new Intent(AdminDashboard.this, TeacherList.class);
                startActivity(pp);


            }
        });
        c2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent pp = new Intent(AdminDashboard.this, AdminCircular.class);
                startActivity(pp);
            }
        });




    }
}