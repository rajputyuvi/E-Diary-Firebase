package com.example.ediary;
import android.content.Context;
import com.prolificinteractive.materialcalendarview.CalendarDay;
import com.prolificinteractive.materialcalendarview.DayViewDecorator;
import com.prolificinteractive.materialcalendarview.DayViewFacade;

import java.util.Collection;
import java.util.HashSet;

public class Presentdaydecorator implements DayViewDecorator {

    private final HashSet<CalendarDay> dates;
    private final Context context;

    public Presentdaydecorator(Context context, Collection<CalendarDay> dates) {
        this.context = context;
        this.dates = new HashSet<>(dates);  // Better performance for lookup
    }

    @Override
    public boolean shouldDecorate(CalendarDay day) {
        return dates.contains(day);
    }

    @Override
    public void decorate(DayViewFacade view) {
        view.setBackgroundDrawable(context.getResources().getDrawable(R.drawable.red_background));
    }
}
