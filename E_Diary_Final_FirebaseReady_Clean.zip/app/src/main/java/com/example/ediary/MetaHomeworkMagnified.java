package com.example.ediary;
public class MetaHomeworkMagnified {
    private String id;
    private String name;
    private String email;
    private String phone;
    // private String city;
    private String work;

    //  private String spec;
    //  private String status;
    // String startdate;

    public  MetaHomeworkMagnified( String id,String name, String email, String phone, String work) {
        this.id = id;
        this.name = name;
        this.email = email;
        this.phone = phone;
        this.work = work;

    }

    public String getB_area() {
        return id;
    }

    public void setB_area(String b_id) {
        this.id = id;
    }

    public String getB_email() {
        return name;
    }

    public void setB_email(String b_area) {
        this.name = name;
    }

    public String getB_work() {
        return email;
    }

    public void setB_work(String b_work) {
        this.email = email;
    }


    public String getB_wardno() {
        return work;
    }

    public void setB_wardno(String b_wardno) {
        this.work = work;
    }
    public String getB_ward() {
        return phone;
    }

    public void setB_ward(String b_wardno) {
        this.phone = phone;
    }





}
