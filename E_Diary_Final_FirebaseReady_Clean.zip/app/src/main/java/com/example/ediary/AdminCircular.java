package com.example.ediary;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import java.util.HashMap;
import java.util.Map;

public class AdminCircular extends AppCompatActivity {
    Button b1;
    EditText e1 ,e2;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_admincircular);
        b1= (Button) findViewById(R.id.uploadcircularr);
        e1=(EditText) findViewById(R.id.notice);
        e2=(EditText) findViewById(R.id.uploadedby);
        b1.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View view) {
                String s1, s2;
                s1 = e1.getText().toString();
                s2 = e2.getText().toString();

                final String HI = "https://letuslearnenglish.in/jaineet/adminuploadcircular.php";

                StringRequest stringRequest = new StringRequest(Request.Method.POST, HI, new Response.Listener<String>() {
                    @Override

                    public void onResponse(String response) {
                        Toast.makeText(AdminCircular.this, "log done", Toast.LENGTH_LONG).show();


                        Intent intent = new Intent(AdminCircular.this, TeacherDashboard.class);
                        intent.putExtra("name", s1);
                        startActivity(intent);
                    }

                }, new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        Toast.makeText(AdminCircular.this, "data not saved", Toast.LENGTH_LONG).show();
                    }

                }) {
                    @Override
                    protected Map<String, String> getParams() throws AuthFailureError {
                        Map<String, String> parms = new HashMap<String, String>();

                        parms.put("s1", s1);
                        parms.put("s2", s2);

                        return parms;
                    }
                };
                RequestQueue requestQueue = Volley.newRequestQueue(getApplicationContext());
                requestQueue.add(stringRequest);
            }
        });



    }
}

