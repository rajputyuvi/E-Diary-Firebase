package com.example.ediary;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioGroup;
import android.widget.Spinner;
import android.widget.Toast;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import java.util.HashMap;
import java.util.Map;

public class Signup extends AppCompatActivity    {
    Button b1;
    EditText e1 ,e2,e3,e4,e5,e6,e9,e10;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_signup);
        b1 = (Button) findViewById(R.id.buttonSignUp);
        e1 = (EditText) findViewById(R.id.firstname);
        e2 = (EditText) findViewById(R.id.lastname);
        e3 = (EditText) findViewById(R.id.Email);
        e4 = (EditText) findViewById(R.id.mobilenumber);
        e5 = (EditText) findViewById(R.id.address);
        e6 = (EditText) findViewById(R.id.number);
        e9 = (EditText) findViewById(R.id.password);
       // e10 = (EditText) findViewById(R.id.confirmpassword);
       // spinner=(Spinner)findViewById(R.id.spin) ;
     //   spinner.setOnItemSelectedListener(this);
      /*  ArrayAdapter a
                = new ArrayAdapter(
                this,
                android.R.layout.simple_spinner_item,
                course);

        a.setDropDownViewResource(
                android.R.layout
                        .simple_spinner_dropdown_item);

        // Set the ArrayAdapter (ad) data on the

        // Spinner which binds data to spinner
        spinner.setAdapter(a);

        spinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
                selectedItem = adapterView.getItemAtPosition(i).toString();

            }

            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {

            }
        });*/

        b1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String s1, s2, s3, s4, s5, s6, s7, s8;
                s1 = e1.getText().toString();
                s2 = e2.getText().toString();
                s3 = e3.getText().toString();
                s4 = e4.getText().toString();
                s5 = e5.getText().toString();
                s6 = e6.getText().toString();
                s7 = e9.getText().toString();
                //  s8 = e10.getText().toString();


                if (s1.isEmpty()) {
                    e1.setError("name can't be empty");
                    e1.requestFocus();  // This puts cursor right in the EditText

                }

                if (s2.isEmpty()) {
                    e2.setError("name can't be empty");
                    e2.requestFocus();  // This puts cursor right in the EditText

                }


                if (s3.isEmpty()) {
                    e3.setError("name can't be empty");
                    e3.requestFocus();  // This puts cursor right in the EditText

                }

                if (s4.isEmpty()) {
                    e4.setError("name can't be empty");
                    e4.requestFocus();  // This puts cursor right in the EditText

                }

                if (s5.isEmpty()) {
                    e5.setError("name can't be empty");
                    e5.requestFocus();  // This puts cursor right in the EditText

                }

                if (s6.isEmpty()) {
                    e6.setError("name can't be empty");
                    e6.requestFocus();  // This puts cursor right in the EditText

                }

                if (s7.isEmpty()) {
                    e9.setError("name can't be empty");
                    e9.requestFocus();  // This puts cursor right in the EditText

                } else {


                    final String HI = "https://letuslearnenglish.in/jaineet/sign.php";

                    StringRequest stringRequest = new StringRequest(Request.Method.POST, HI, new Response.Listener<String>() {
                        @Override


                        public void onResponse(String response) {
                            Toast.makeText(Signup.this, "data saved", Toast.LENGTH_LONG).show();

                            // Intent intent = new Intent(profile.this, MainActivity.class);
                            // intent.putExtra("name",binId);
                            //startActivity(intent);
                        }
                    }, new Response.ErrorListener() {
                        @Override
                        public void onErrorResponse(VolleyError error) {
                            Toast.makeText(Signup.this, "data not saved", Toast.LENGTH_LONG).show();
                        }

                    }) {
                        @Override
                        protected Map<String, String> getParams() throws AuthFailureError {
                            Map<String, String> parms = new HashMap<String, String>();

                            parms.put("s1", s1);
                            parms.put("s2", s2);
                            parms.put("s3", s3);
                            parms.put("s4", s4);
                            parms.put("s5", s5);
                            parms.put("s6", s6);
                            parms.put("s7", s7);
                            // parms.put("s8", s8);

                            return parms;
                        }
                    };
                    RequestQueue requestQueue = Volley.newRequestQueue(getApplicationContext());
                    requestQueue.add(stringRequest);
                }
            }
        });


    }





}





