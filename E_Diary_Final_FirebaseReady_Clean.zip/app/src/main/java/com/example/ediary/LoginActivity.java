package com.example.ediary;
import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class LoginActivity extends AppCompatActivity {
    private EditText username, password;
    private Button loginBtn;
    private TextView forgotPassword, loginTitle;
    private String role;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        username = findViewById(R.id.username);
        password = findViewById(R.id.password);
        loginBtn = findViewById(R.id.loginBtn);
        forgotPassword = findViewById(R.id.forgotPassword);
        loginTitle = findViewById(R.id.loginTitle);

        role = getIntent().getStringExtra("role");
        if (role == null) role = "Student";
        loginTitle.setText(role + " Login");

        loginBtn.setOnClickListener(v -> {
            String user = username.getText().toString().trim();
            String pass = password.getText().toString().trim();

            if (user.isEmpty() || pass.isEmpty()) {
                Toast.makeText(this, "Please enter username and password", Toast.LENGTH_SHORT).show();
                return;
            }

            boolean ok = false;
            if (role.equalsIgnoreCase("Admin")) {
                ok = user.equals("admin") && pass.equals("12345");
            } else if (role.equalsIgnoreCase("Teacher")) {
                ok = user.equals("teacher") && pass.equals("12345");
            } else if (role.equalsIgnoreCase("Student")) {
                ok = user.equals("student") && pass.equals("12345");
            }

            if (ok) {
                Toast.makeText(this, role + " Login Successful", Toast.LENGTH_SHORT).show();
                // Replace these with your Dashboard activities
                if (role.equalsIgnoreCase("Admin")) {
                    startActivity(new Intent(this, MainActivity.class)); // change to AdminDashboardActivity if available
                } else if (role.equalsIgnoreCase("Teacher")) {
                    startActivity(new Intent(this, MainActivity.class)); // change to TeacherDashboardActivity if available
                } else {
                    startActivity(new Intent(this, MainActivity.class)); // change to StudentDashboardActivity if available
                }
                finish();
            } else {
                Toast.makeText(this, "Invalid credentials", Toast.LENGTH_SHORT).show();
            }
        });

        forgotPassword.setOnClickListener(v -> {
            startActivity(new Intent(this, Forgotpasswordactivity.class));
        });
    }
}
