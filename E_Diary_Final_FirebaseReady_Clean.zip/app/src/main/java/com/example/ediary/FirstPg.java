package com.example.ediary;

import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.ImageView;
import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;

import androidx.appcompat.app.AppCompatActivity;

public class FirstPg extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_firstpg);
	ImageView logo = findViewById(R.id.logo);

	// Load bounce animation
	Animation bounce = AnimationUtils.loadAnimation(this, R.anim.bounce);
	logo.startAnimation(bounce);


        // Find buttons by new IDs
        Button btnAdmin = findViewById(R.id.btnAdmin);
        Button btnTeacher = findViewById(R.id.btnTeacher);
        Button btnStudent = findViewById(R.id.btnStudent);

        // Admin button click
        btnAdmin.setOnClickListener(v -> {
            Intent intent = new Intent(FirstPg.this, AdminLogin.class);
            startActivity(intent);
        });

        // Teacher button click
        btnTeacher.setOnClickListener(v -> {
            Intent intent = new Intent(FirstPg.this, TeacherLogin.class);
            startActivity(intent);
        });

        // Student button click
        btnStudent.setOnClickListener(v -> {
            Intent intent = new Intent(FirstPg.this, StudentLogin.class);
            startActivity(intent);
        });
    }
}
