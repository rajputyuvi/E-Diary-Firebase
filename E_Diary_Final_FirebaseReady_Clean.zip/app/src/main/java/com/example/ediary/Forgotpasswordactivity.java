package com.example.ediary;
import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class Forgotpasswordactivity extends AppCompatActivity {
    private EditText emailInput;
    private Button resetBtn;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_forgot_password);

        emailInput = findViewById(R.id.emailInput);
        resetBtn = findViewById(R.id.resetBtn);

        resetBtn.setOnClickListener(v -> {
            String email = emailInput.getText().toString().trim();
            if (email.isEmpty()) {
                Toast.makeText(this, "Please enter your email", Toast.LENGTH_SHORT).show();
                return;
            }
            // currently local placeholder behavior; if Firebase later, replace with Firebase logic
            Toast.makeText(this, "Reset link (simulated) sent to: " + email, Toast.LENGTH_LONG).show();
            finish();
        });
    }
}
