package com.example.ediary;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioGroup;
import android.widget.Spinner;
import android.widget.Toast;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import java.util.HashMap;
import java.util.Map;

public class AddStudentDetails extends AppCompatActivity    {
    Button b1;
    EditText e1 ,e2,e3,e4,e5,e6,e7,e8,e9,e10,e11,e12,e13;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_addstudentdetails);
        b1 = (Button) findViewById(R.id.buttonSignUp);
        e1 = (EditText) findViewById(R.id.firstname);
        e2 = (EditText) findViewById(R.id.lastname);
        e3 = (EditText) findViewById(R.id.Email);
        e4 = (EditText) findViewById(R.id.mobilenumber);
        e5 = (EditText) findViewById(R.id.address);
        e6 = (EditText) findViewById(R.id.number);
        e7 = (EditText) findViewById(R.id.admissionno);
        e8 = (EditText) findViewById(R.id.pickup);
        e9 = (EditText) findViewById(R.id.pick);
        e10 = (EditText) findViewById(R.id.pickupp);
        e11 = (EditText) findViewById(R.id.droppoint);
        e12= (EditText) findViewById(R.id.driver);
        e13 = (EditText) findViewById(R.id.incharge);
        // spinner=(Spinner)findViewById(R.id.spin) ;
        //   spinner.setOnItemSelectedListener(this);
      /*  ArrayAdapter a
                = new ArrayAdapter(
                this,
                android.R.layout.simple_spinner_item,
                course);

        a.setDropDownViewResource(
                android.R.layout
                        .simple_spinner_dropdown_item);

        // Set the ArrayAdapter (ad) data on the

        // Spinner which binds data to spinner
        spinner.setAdapter(a);

        spinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
                selectedItem = adapterView.getItemAtPosition(i).toString();

            }

            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {

            }
        });*/

        b1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String s1, s2, s3, s4, s5,s6,s7,s8,s9,s10,s11,s12,s13;
                s1 = e1.getText().toString();
                s2 = e2.getText().toString();
                s3 = e3.getText().toString();
                s4 = e4.getText().toString();
                s5 = e5.getText().toString();
                s6 = e6.getText().toString();
                s7 = e7.getText().toString();
                s8 = e8.getText().toString();
                s9 = e9.getText().toString();
                s10= e10.getText().toString();
                s11= e11.getText().toString();
                s12= e12.getText().toString();
                s13= e13.getText().toString();



                final String HI  ="https://letuslearnenglish.in/jaineet/studata.php";

                StringRequest stringRequest = new StringRequest(Request.Method.POST, HI, new Response.Listener<String>() {
                    @Override


                    public void onResponse(String response) {
                        Toast.makeText(AddStudentDetails.this, "data saved", Toast.LENGTH_LONG).show();

                        // Intent intent = new Intent(profile.this, MainActivity.class);
                        // intent.putExtra("name",binId);
                        //startActivity(intent);
                    }
                }, new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        Toast.makeText(AddStudentDetails.this, "data not saved", Toast.LENGTH_LONG).show();
                    }

                }) {
                    @Override
                    protected Map<String, String> getParams() throws AuthFailureError {
                        Map<String, String> parms = new HashMap<String, String>();

                        parms.put("s1", s1);
                        parms.put("s2", s2);
                        parms.put("s3", s3);
                        parms.put("s4", s4);
                        parms.put("s5", s5);
                        parms.put("s6", s6);
                        parms.put("s7", s7);
                        parms.put("s8", s8);
                        parms.put("s9", s9);
                        parms.put("s10", s10);
                        parms.put("s11", s11);
                        parms.put("s12", s12);
                        parms.put("s13", s13);

                        return parms;
                    }
                };
                RequestQueue requestQueue = Volley.newRequestQueue(getApplicationContext());
                requestQueue.add(stringRequest);
            }
        });


    }





}





