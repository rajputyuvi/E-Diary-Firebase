package com.example.ediary;
import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

public class TeacherAdapter extends RecyclerView.Adapter< TeacherAdapter .ProductViewHolder> {
    Button b;
    private Context mCtx;
    private List<MetaTeacher> productList;

    public TeacherAdapter(Context mCtx, List<MetaTeacher> productList) {
        this.mCtx = mCtx;
        this.productList = productList;
    }


    public TeacherAdapter.ProductViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        LayoutInflater inflater = LayoutInflater.from(mCtx);
        View view = inflater.inflate(R.layout.myteacherlist,null);
        return new com.example.ediary.TeacherAdapter.ProductViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull com.example.ediary.TeacherAdapter.ProductViewHolder holder, int position) {
        MetaTeacher product = productList.get(position);

        //loading the image
        //  Glide.with(mCtx)
        //    .load(product.getImage())
        //  .into(holder.imageView);

        holder.textViewId.setText(product.getB_area());

        // holder.textViewLocality.setText(String.valueOf(product.getB_wardno()));


    }

    @Override
    public int getItemCount() {
        return productList.size();
    }

    class ProductViewHolder extends RecyclerView.ViewHolder {

        TextView textViewId,textViewArea, textViewWardno, textViewLocality, textViewCity, textViewEmail,textViewRoute;

        ImageView imageView;
        Button updateMap,updateBin;

        public ProductViewHolder(View itemView) {
            super(itemView);
            //imageView=itemView.findViewById(R.id.ing);
            textViewId=itemView.findViewById(R.id.c1);




            /* textViewCity.setEnabled(false);
             textViewArea.setEnabled(false);
             textViewWardno.setEnabled(false);
             textViewLocality.setEnabled(false);
             textViewId.setEnabled(false);*/


            // imageView = itemView.findViewById(R.id.imageView);
        }
    }

}
